#!/usr/bin/env python
import rospy
import math
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf.transformations import quaternion_from_euler
import tf

# 定数設定
WHEEL_BASE = 0.375  # 車輪間の距離（メートル）
WHEEL_RADIUS = 0.065  # 車輪の半径（メートル）
ENCODER_RESOLUTION = 4096.0  # エンコーダの分解能
PWM_MAX = 255  # PWMの最大値（仮定）

# グローバル変数
speed = [0, 0]  # [左モーター速度, 右モーター速度]
encoder_counts = [0, 0]  # [左エンコーダカウント, 右エンコーダカウント]
x = 0.0  # x座標
y = 0.0  # y座標
theta = 0.0  # ロボットの向き
prev_left = 0  # 左エンコーダの前回値
prev_right = 0  # 右エンコーダの前回値
pwm = [0, 0]  # モータ回転速度（PWM信号）
SPEED_SCALE=2
linear_velocity = 0.0  # ロボットの並進速度
angular_velocity = 0.0  # ロボットの角速度
actual_speed = [0.0, 0.0] 

# エンコーダのコールバック関数
def encoder_callback(data):
    global encoder_counts, actual_speed, prev_left, prev_right, linear_velocity, angular_velocity,x,y,theta
    encoder_counts = data.data  # [左エンコーダカウント, 右エンコーダカウント]

    delta_left = encoder_counts[0] - prev_left
    delta_right = encoder_counts[1] - prev_right
    prev_left = encoder_counts[0]
    prev_right = encoder_counts[1]
    #[m/s]
    actual_speed[0] = (delta_left / ENCODER_RESOLUTION) * (2.0 * math.pi * WHEEL_RADIUS) * 40.0  # 0.1はループ周期 m/s
    actual_speed[1] = (delta_right / ENCODER_RESOLUTION) * (2.0 * math.pi * WHEEL_RADIUS) * 40.0
    rospy.loginfo(f"Encoder counts: Left={encoder_counts[0]}, Right={encoder_counts[1]}")
   # ロボットの並進速度と角速度を計算
    linear_velocity = (actual_speed[0] + actual_speed[1]) / 2.0
    angular_velocity = (actual_speed[1] - actual_speed[0]) / WHEEL_BASE
    
        # 左右の移動距離を計算
    d_left = (delta_left / ENCODER_RESOLUTION) * (2.0 * math.pi * WHEEL_RADIUS)#[m/Ts]
    d_right = (delta_right / ENCODER_RESOLUTION) * (2.0 * math.pi * WHEEL_RADIUS)#[m/Ts]
    d_center = (d_left + d_right)*0.3 / 2.0#[m]
    d_theta = (d_right - d_left)*0.3 / (WHEEL_BASE)#[rad/Ts]
    
    # ロボットの座標と向きを更新
    #theta += d_theta  # 向きを更新
    #theta = (theta + math.pi) % (2 * math.pi) - math.pi  # 正規化して [-π, π] の範囲に収める
    theta =theta+d_theta#[rad]
    x = x+d_center * math.cos(theta)
    y = y+d_center * math.sin(theta)


    
# cmd_velのコールバック関数
def cmd_vel_callback(msg):
    global speed, pwm
    linear_x = msg.linear.x
    angular_z = msg.angular.z
    
    # 左右のモーターの速度を計算（scale_value*ラジアン/秒）
    pwm[0] = int((((30/math.pi)*(linear_x - angular_z * WHEEL_BASE / 2.0) / WHEEL_RADIUS)+8)/1.1)
    pwm[1] = int((((30/math.pi)*(linear_x + angular_z * WHEEL_BASE / 2.0) / WHEEL_RADIUS)+10)/1.1)
    
    # モータ速度をPWM値に変換（線形変換: 仮定で作成）
    #pwm[0] = speed[0] * SPEED_SCALE
    #pwm[1] = speed[1] * SPEED_SCALE
    #rospy.loginfo(f"Calculated PWM: Left={pwm[0]}, Right={pwm[1]}")

# オドメトリの計算とパブリッシュ
def publish_odom(tf_broadcaster):
    global x, y, theta, encoder_counts, prev_left, prev_right

        
    # クォータニオンの計算
    odom_quat = quaternion_from_euler(0, 0, theta)

    # オドメトリメッセージの作成
    odom = Odometry()
    odom.header.stamp = rospy.Time.now()
    odom.header.frame_id = "odom"
    odom.child_frame_id = "base_link"
    
    # 位置
    odom.pose.pose.position.x = x
    odom.pose.pose.position.y = y
    odom.pose.pose.position.z = 0.0
    odom.pose.pose.orientation.x = odom_quat[0]
    odom.pose.pose.orientation.y = odom_quat[1]
    odom.pose.pose.orientation.z = odom_quat[2]
    odom.pose.pose.orientation.w = odom_quat[3]
    odom.twist.twist.linear.x = linear_velocity
    odom.twist.twist.angular.z = angular_velocity
    # パブリッシュ
    odom_pub.publish(odom)
  
    # tfに座標変換を送信
    tf_broadcaster.sendTransform(
        (x, y, 0),                  # 平行移動
        odom_quat,                  # 回転
        rospy.Time.now(),           # タイムスタンプ
        "base_link",                # 子フレーム
        "odom"                      # 親フレーム
    )

# メイン処理
def motor_command_sender():
    rospy.init_node('motor_command_sender', anonymous=True)
    
    # パブリッシャの設定
    pub_speed = rospy.Publisher('pwm', Int32MultiArray, queue_size=10)
    global odom_pub
    odom_pub = rospy.Publisher('odom', Odometry, queue_size=10)
    
    # サブスクライバの設定
    rospy.Subscriber('cmd_vel', Twist, cmd_vel_callback)
    rospy.Subscriber('encoder', Int32MultiArray, encoder_callback)
    
    # tfブロードキャスターの初期化
    tf_broadcaster = tf.TransformBroadcaster()
    
    rate = rospy.Rate(30)  # 30Hz
    
    while not rospy.is_shutdown():
        # 速度配列をArduinoにパブリッシュ
        speed_msg = Int32MultiArray(data=pwm)
        rospy.loginfo(f"Sending speeds: Left={pwm[0]}, Right={pwm[1]}")
        pub_speed.publish(speed_msg)
        
        # オドメトリとtfをパブリッシュ
        publish_odom(tf_broadcaster)

        rate.sleep()

if __name__ == '__main__':
    try:
        motor_command_sender()
    except rospy.ROSInterruptException:
        pass
