#!/usr/bin/env python3
import cv2
import numpy as np
import rospy
from std_msgs.msg import String  # ROSメッセージ型

# ROSノードの初期化
rospy.init_node("wound_detection_node", anonymous=True)

# 傷検出メッセージのパブリッシャー
pub = rospy.Publisher("detection_wounds", String, queue_size=10)

# カメラのセットアップ
device_index = 0  # カメラのデバイス番号
cap = cv2.VideoCapture(device_index)

# 傷とみなす明るさの範囲
min_brightness = 110  # 110以上
max_brightness = 160  # 160以下
min_area = 150
max_area = 700

while not rospy.is_shutdown():  # ROSが動作している間はループ
    ret, frame = cap.read()
    if not ret:
        rospy.logerr("カメラからフレームを取得できませんでした。")
        break

    # HSV色空間に変換し、明るさチャンネル（V）を取得
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    value_channel = hsv[:, :, 2]

    # 明るさが 110～160 の領域のみをマスク
    mask_brightness = cv2.inRange(value_channel, min_brightness, max_brightness)

    # エッジ検出 → 輪郭抽出
    edges = cv2.Canny(mask_brightness, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # 傷の検出処理
    detected = False  # このフレームで傷を検出したか
    for contour in contours:
        area = cv2.contourArea(contour)
        if min_area <= area <= max_area:  # 一定以上の大きさがある場合
            detected = True  # 傷を検出

            # 傷の部分を赤枠で強調
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(frame, "Wound Detected", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

    # 傷が検出されたら毎回トピックを発行
    if detected:
        rospy.loginfo("傷が検出されました！")
        pub.publish("傷が検出されました")

    # 結果を表示
    cv2.imshow("Detected Scratches", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()


