#!/usr/bin/env python3
import cv2
import numpy as np
import rospy
import yaml
from std_msgs.msg import String
from geometry_msgs.msg import PoseWithCovarianceStamped

size_y = 517.0  # 地図のピクセルサイズ

# 最新の amcl_pose を保持する変数
latest_pose = None

# YAMLファイルの読み込み関数
def load_yaml_config(yaml_path):
    try:
        with open(yaml_path, 'r') as file:
            config = yaml.safe_load(file)
            return config
    except Exception as e:
        rospy.logerr(f"YAMLファイルの読み込みに失敗しました: {e}")
        return None

# 地図画像の読み込み
map_image_path = "/home/ubuntu/catkin_ws/src/camera_ditection/marked/nit_gymnasium.pgm"
map_image = cv2.imread(map_image_path, cv2.IMREAD_COLOR)
if map_image is None:
    rospy.logerr(f"地図画像 '{map_image_path}' が見つかりません。プログラムを終了します。")
    exit()

# YAML設定ファイルの読み込み
config = load_yaml_config("/home/ubuntu/catkin_ws/src/camera_ditection/maps/nit_gymnasium.yaml")
if config is None:
    rospy.logerr("YAML設定の読み込みに失敗したため、プログラムを終了します。")
    exit()

# 地図スケールの設定
origin_x = config.get('origin', [10, 10, 0])[0]  # X原点
origin_y = config.get('origin', [10, 10, 0])[1]  # Y原点
resolution = config.get('resolution', 0.05)  # 1ピクセルあたりのメートル値

# amcl_pose のコールバック関数
def amcl_pose_callback(msg):
    global latest_pose
    latest_pose = msg.pose.pose.position

# detection_wounds のコールバック関数
def mark_on_map(_):
    global latest_pose, map_image

    if latest_pose is None:
        rospy.logwarn("まだ amcl_pose を受信していません。")
        return

    pose_x = latest_pose.x
    pose_y = latest_pose.y

    # 地図上の座標に変換
    map_x = int((pose_x - origin_x) / resolution)
    map_y = int(size_y - ((pose_y - origin_y) / resolution))

    if 0 <= map_x < map_image.shape[1] and 0 <= abs(map_y) < map_image.shape[0]:
        # 地図上に赤丸でマーク
        cv2.circle(map_image, (map_x, map_y), 5, (0, 0, 255), -1)
        success_png = cv2.imwrite("/home/ubuntu/catkin_ws/src/camera_ditection/marked/nit_gymnasium.png", map_image)
        success_pgm = cv2.imwrite("/home/ubuntu/catkin_ws/src/camera_ditection/marked/nit_gymnasium.pgm", map_image)

        if success_png and success_pgm:
            rospy.loginfo(f"マーク付き地図を保存しました (x={pose_x}, y={pose_y})")
        else:
            rospy.logerr("地図の保存に失敗しました。")
    else:
        rospy.logwarn(f"座標が地図範囲外です (x={pose_x}, y={pose_y})。マークをスキップします。")

# ROSの初期化
rospy.init_node("map_marker_node", anonymous=True)

# トピックの購読
rospy.Subscriber("amcl_pose", PoseWithCovarianceStamped, amcl_pose_callback)
rospy.Subscriber("detection_wounds", String, mark_on_map)

rospy.loginfo("地図マーキングノードが起動しました。amcl_pose と detection_wounds を待機しています...")
rospy.spin()


